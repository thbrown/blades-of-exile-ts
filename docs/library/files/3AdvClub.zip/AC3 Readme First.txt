
Thanks for downloading my scenario, "Adventurer's Club 3: Retribution, Part 1".


  Yes, this is the first part of the 3rd installment of the "Adventurer's Club"
series. You needn't have played the first two games to enjoy this one, but
there are many references to the first games in this one which you may not
understand if you haven't. A quick synposis of the first two games can be found
by visiting one of the schoolteachers in the residential area of Independence
City.

  The second half of this game is under development and will be released shortly.
(spring of 2004??) Upon finishing the first part, you must make an in-game save 
and keep it to use for the second half. Part 2 will not be a stand alone game. 
It will be a continuation of this game. When it is released, it will be Part 1
and Part 2 combined. If you do not have a save game from Part 1, you will have 
to start from the very beginning.

  This is a large, somewhat nonlinear game. There is a main plot and many side
quests. The side quests are optional, but completing them will gain your party
lots of experience and several powerful items that you will find very helpful,
especially with some of the tougher battles near the end. I have included a file
that lists the side quests and where to get them. 

  This game was designed for a beginning party. One of the main features of this 
game is the growth and development of a weak party into a strong one. If you
insist on using a high level party please refrain from using the Word of Recall
spell. It may break the game if used in certain areas.

  For Mac users...The file, '3AdvClub.meg.sit' was created by Terrors Martyr by
altering my original .bmp file to look better with the Mac version. I have no way
to view this file myself, but I trust his expertise and I recommend using this 
file while playing the game. Just unstuff it and place it in the proper folder.
Thanks TM!

  Included with the game are two maps...West Zinlasia.gif and East Zinlasia.gif.
These are the two main areas you will be exploring. You can get mini versions of
them in the game by visiting the tourist centers in the big cities. But those are
so small and hard to read I'm sure you will prefer using the large maps. But keep
in mind that these maps are so detailed that they contain some spoilers. Use them 
at your discretion. These were graciously created by Desert Plah. Thanks dp!  


  If you have any questions, comments or bug findings, please feel
free to contact me at Shyguy123@msn.com. Thanks again.

                                                    


           Here is a list of known issues in the game.

1.There are several words containing apostrophes in the game, such as
   "T'Lanhg". When in dialog mode, enter the letters only when enquiring
    about a subject. example: enter "tlan" for "T'Lanhg".

2.There are many dungeon maps that contain multiple areas. This was done
  to get around the 100 town bug. (Yes, I know there's another way now)
  Just be aware when using the Magic Map spell or just looking at the
  automap that it may appear that there are areas that can't be reached.
  These are separate areas that can only be reached from other spots on
  the world map.

3.When visiting the "Mind Games" entertainment facility, if you immediately
  replay the same "game" it will not work properly. The town must be reset
  by either visiting 3 different areas before coming back, or just using
  the town reset keys ("shift" + ">"). Actually, there is no reason you 
  would want to replay the same "game".  ;)

4.It is possible to sail a boat into the city of Zenith and become
  forever stranded in the middle of the street. Don't!

5.If you win the Owaji Championship, you may encounter a 50 node error report.
  This may result in not winning the grand prize but almost always allows you
  to play again. It's an issue that is much too complex to fix without recoding
  the whole thing and frankly, it's just not that important. 




     Good adventuring, Jeff Weisler





Acknowlegements

  Thanks go to the following people whose graphics I borrowed and abused
throughout my game. (If I've given credit to the wrong people, or you
see your graphics used and your name omitted from this list, feel free 
to let me know and I will gladly add you to the list)

         Aceron, Relhan, Luz, Elvin Windleaf, Tim Farland, Birdy 
                    Justifier, Shawn Lonergan, Shyguy



These are the authors who graciously let me use their scenario names in 
my game.

Brett Bixler   (Quintessence)
The Creator    (Deadly Goblins)
Drizzt         (The Forsaken)
Lt. Sullust    (The Expedition)
Stareye        (Spears)
Terrors Martyr (tehGRICH!!!)
and especially Zxquez (A Little Girl)



And I want to especially thank my playtesters who helped considerably in 
getting this game as bug free as possible.

Conundrum, Desert Plah, Ezra Strong, fluffypinkpotatoes, Jayne, Lt. Triest
        Princess Ruth, Milla, The Mighty Kobold, Terrors Martyr  


 